package it.polito.ai.gas.business;

import org.springframework.roo.addon.jpa.identifier.RooIdentifier;

@RooIdentifier(dbManaged = true)
public final class MessagePK {
}
